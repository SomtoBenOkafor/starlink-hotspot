const jwt           = require('jsonwebtoken');
const { userHelpers } = require('../db');

/**
 * Middleware: verify JWT from Authorization header or cookie.
 * Attaches req.user = { id, name, email } on success.
 */
function requireAuth(req, res, next) {
  /* Accept token from Authorization: Bearer <token> or cookie */
  const authHeader = req.headers.authorization || '';
  const token =
    (authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null) ||
    req.cookies?.token;

  if (!token) {
    return res.status(401).json({ success: false, message: 'Not authenticated.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user    = userHelpers.findById.get(payload.id);
    if (!user) {
      return res.status(401).json({ success: false, message: 'User not found.' });
    }
    req.user = { id: user.id, name: user.name, email: user.email };
    next();
  } catch {
    return res.status(401).json({ success: false, message: 'Invalid or expired token.' });
  }
}

module.exports = { requireAuth };
